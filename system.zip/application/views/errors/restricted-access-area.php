<div class="container body">
    <div class="main_container">
        <div class="col-md-12">
            <div class="col-middle">
                <div class="text-center text-center">
                    <h1 class="error-number">403</h1>
                    <h2>Access denied</h2>
                    <p>You don't have the account level you need to access this page.</p>
                    <button onclick="window.history.back();" class="btn btn-primary">Go Back</button>
                </div>
            </div>
        </div>
    </div>
</div>