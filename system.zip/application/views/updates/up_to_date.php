<?php
echo '<h3>Everything is already updated!</h3>';